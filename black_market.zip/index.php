<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
ini_set('max_execution_time', 9000);

header('Content-type: text/html; charset=utf-8');
require_once 'vendor/electrolinux/phpquery/phpQuery/phpQuery.php';

require_once "parser/connection/ConnectionByCurl.php";
require_once "parser/ParseSilpo.php";
require_once "parser/ParseATB.php";

$connectionType = new ConnectionByCurl();
$silpoParser = new ParseATB();
$silpoParser->setSiteCode($connectionType);
$silpoParser->parseProductsFromCode();
echo "<pre>";
print_r($silpoParser->getProductsData());
echo "</pre>";